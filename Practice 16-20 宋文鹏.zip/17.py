#循环语句

#while语句
# !/usr/bin/env python3

n = 100

sum = 0
counter = 1
while counter <= n:
    sum = sum + counter
    counter += 1

print("1 到 %d 之和为: %d" % (n, sum))

#无限循环
# !/usr/bin/python3

var = 1
while var == 1:  # 表达式永远为 true
    num = int(input("输入一个数字  :"))
    print("你输入的数字是: ", num)

print("Good bye!")
#while 循环使用 else 语句
# !/usr/bin/python3

var = 1
while var == 1:  # 表达式永远为 true
    num = int(input("输入一个数字  :"))
    print("你输入的数字是: ", num)

print("Good bye!")

#简单语句组
# !/usr/bin/python

flag = 1

while (flag): print('欢迎访问菜鸟教程!')

print("Good bye!")