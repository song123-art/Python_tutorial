#5.1 Python3 基本数据类型  Python 中的变量不需要声明。每个变量在使用前都必须赋值，变量赋值以后该变量才会被创建。
x = 10           #整型变量
y = 10.0         #浮点型变量
z = "python"    #字符串
print(x)
print(y)
print(z)
print("----------------------")
#5.2 多个变量赋值
a1 = a2 = a3 = 1
b1, b2, b3 = 1, 2, "python"
print(a1);print(a2);print(a3)
print(b1);print(b2);print(b3)
print("----------------------")
#5.3 查询变量所指的对象类型。
c1, c2, c3, c4 = 10, 10.0, "python",True
print(type(c1),type(c2),type(c3),type(c4))
print("----------------------")
#5.4 数值运算
d1, d2 = 7, 5
print(d1 + d2)   #加法
print(d1 - d2)   #减法
print(d1 * d2)   #乘法
print(d1 / d2)   #除法，得到一个浮点数
print(d1 // d2)  #除法，得到一个整数
print(d1 % d2)   #取余
print(d1 ** d2)  #等价于 7的5次幂  乘方
print("----------------------")
#5.5 String（字符串）
str = "python"
print(str) #输出整个字符串
print(str[0:-1]) #输出第一个到倒数第二个的字符
print(str[2]) #输出第三个字符
print(str[1:]) #输出第二个到最后的字符
print(str * 2)  #输出两边字符
print(str + "test") #链接字符串
print("----------------------")
#5.6 列表
list = ['abcd', 786, 2.23, 'runoob', 70.2]
tinylist = [123, 'runoob']
print(list)  # 输出完整列表
print(list[0])  # 输出列表第一个元素
print(list[1:3])  # 从第二个开始输出到第三个元素
print(list[2:])  # 输出从第三个元素开始的所有元素
print(tinylist * 2)  # 输出两次列表
print(list + tinylist)  # 连接列表
print("----------------------")
#5.7 Tuple（元组）
tuple = ('abcd', 786, 2.23, 'runoob', 70.2)
tinytuple = (123, 'runoob')
print(tuple)  # 输出完整元组
print(tuple[0])  # 输出元组的第一个元素
print(tuple[1:3])  # 输出从第二个元素开始到第三个元素
print(tuple[2:])  # 输出从第三个元素开始的所有元素
print(tinytuple * 2)  # 输出两次元组
print(tuple + tinytuple)  # 连接元组
print("----------------------")
#5.8 Set（集合）
student = {'Tom', 'Jim', 'Mary', 'Tom', 'Jack', 'Rose'}
print(student)  # 输出集合，重复的元素被自动去掉
# 成员测试
if 'Rose' in student:
    print('Rose 在集合中')
else:
    print('Rose 不在集合中')
# set可以进行集合运算
a = set('abracadabra')
b = set('alacazam')
print(a)
print(a - b)  # a 和 b 的差集
print(a | b)  # a 和 b 的并集
print(a & b)  # a 和 b 的交集
print(a ^ b)  # a 和 b 中不同时存在的元素
print("----------------------")
#5.9 Dictionary（字典）
dict = {}
dict['one'] = "1 - 菜鸟教程"
dict[2] = "2 - 菜鸟工具"
tinydict = {'name': 'runoob', 'code': 1, 'site': 'www.runoob.com'}
print(dict['one'])  # 输出键为 'one' 的值
print(dict[2])  # 输出键为 2 的值
print(tinydict)  # 输出完整的字典
print(tinydict.keys())  # 输出所有键
print(tinydict.values())  # 输出所有值
