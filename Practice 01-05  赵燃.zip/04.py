print("python 的保留字：'False', 'None', 'True', 'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del',"
      " 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', "
      "'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'")
print('------------------------------')
#4.1 注释
print("Hello,Python") #第二个注释

'''
第三个注释
第四个注释
'''

"""
第五个注释
第六个注释
"""

#4.2 行与缩进  同一个代码块的语句必须包含相同的缩进空格数。实例如下：
'''
if True:
    print("True")
else:
    print("False") #如果缩进数的空格数不一致，会导致运行错误
'''

#4.3 多行语句  Python 通常是一行写完一条语句，但如果语句很长，我们可以使用反斜杠(\)来实现多行语句，例如：
"""
total = item_one + \
           item_two + \
           item_three
"""

#4.4 在 [], {}, 或 () 中的多行语句，不需要使用反斜杠(\)，例如：
'''
total = ['item_one', 'item_two', 'item_three',
        'item_four', 'item_five']
'''
print('------------------------------')
#4.5 字符串
str = 'Runoob'
print(str)  # 输出字符串
print(str[0:-1])  # 输出第一个到倒数第二个的所有字符
print(str[0])  # 输出字符串第一个字符
print(str[2:5])  # 输出从第三个开始到第五个的字符
print(str[2:])  # 输出从第三个开始的后的所有字符
print(str * 2)  # 输出字符串两次
print(str + '你好')  # 连接字符串

print('------------------------------')

print('hello\nrunoob')  # 使用反斜杠(\)+n转义特殊字符
print(r'hello\nrunoob')  # 在字符串前面添加一个 r，表示原始字符串，不会发生转义

print('------------------------------')
#4.6 等待用户输入
input("\n\n按下 enter 键后退出。")

#4.7 Print 输出   print 默认输出是换行的，如果要实现不换行需要在变量末尾加上 end=""：
print('------------------------------')
x = "a"
y = "b"
#4.8 换行输出
print(x)
print(y)

print('---------')
#4.9 不换行输出
print(x, end=" ")
print(y, end=" ")
print()