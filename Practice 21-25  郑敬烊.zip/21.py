# 21.1 Python3 模块
import sys
print('命令行参数如下:')
for i in sys.argv:
    print(i)
print('\n\nPython 路径为：', sys.path, '\n')


# 21.2 斐波那契(fibonacci)数列模块
def fib(n):  # 定义到 n 的斐波那契数列
    a, b = 0, 1
    while b < n:
        print(b, end=' ')
        a, b = b, a + b
    print()
def fib2(n):  # 返回到 n 的斐波那契数列
    result = []
    a, b = 0, 1
    while b < n:
        result.append(b)
        a, b = b, a + b
    return result

# 21.3 __name__属性
if __name__ == '__main__':
   print('程序自身在运行')
else:
   print('我来自另一模块')