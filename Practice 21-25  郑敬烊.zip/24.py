# #OS 文件/目录方法
# os 模块提供了非常丰富的方法用来处理文件和目录。常用的方法如下表所示：
#
# 序号	方法及描述
# 1	     os.access(path, mode) 检验权限模式
# 2	     os.chdir(path) 改变当前工作目录
# 3	     os.chflags(path, flags) 设置路径的标记为数字标记。
# 4	     os.chmod(path, mode) 更改权限
#......